-- Picksy MVP database schema.
-- Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.polls (
  id uuid primary key default gen_random_uuid(),
  question text not null check (char_length(question) between 1 and 100),
  category text not null default 'general',
  created_at timestamptz not null default now(),
  is_open boolean not null default true
);

create table if not exists public.poll_options (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references public.polls(id) on delete cascade,
  label text not null check (char_length(label) between 1 and 60),
  position integer not null,
  unique (poll_id, position)
);

create table if not exists public.poll_votes (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references public.polls(id) on delete cascade,
  option_id uuid not null references public.poll_options(id) on delete cascade,
  voter_token text not null check (char_length(voter_token) between 20 and 100),
  created_at timestamptz not null default now(),
  unique (poll_id, voter_token)
);

create index if not exists poll_options_poll_id_idx on public.poll_options(poll_id);
create index if not exists poll_votes_poll_id_idx on public.poll_votes(poll_id);

alter table public.polls enable row level security;
alter table public.poll_options enable row level security;
alter table public.poll_votes enable row level security;

drop policy if exists "Anyone can read polls" on public.polls;
create policy "Anyone can read polls" on public.polls for select using (true);
drop policy if exists "Anyone can read options" on public.poll_options;
create policy "Anyone can read options" on public.poll_options for select using (true);

-- Votes are intentionally not directly readable or writable by clients.
-- The RPC functions below validate and perform writes without exposing voter tokens.

create or replace function public.create_poll(p_question text, p_category text, p_options text[])
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  new_poll_id uuid;
  option_text text;
  option_index integer := 0;
begin
  if p_question is null or length(trim(p_question)) < 1 or length(trim(p_question)) > 100 then
    raise exception 'Question must be between 1 and 100 characters.';
  end if;
  if p_options is null or array_length(p_options, 1) < 2 or array_length(p_options, 1) > 8 then
    raise exception 'Add between 2 and 8 options.';
  end if;
  if exists (
    select 1 from unnest(p_options) as x
    where x is null or length(trim(x)) < 1 or length(trim(x)) > 60
  ) then
    raise exception 'Each option must be between 1 and 60 characters.';
  end if;
  if (select count(distinct lower(trim(x))) from unnest(p_options) as x) <> array_length(p_options, 1) then
    raise exception 'Options must be unique.';
  end if;

  insert into public.polls(question, category)
  values (trim(p_question), coalesce(nullif(trim(p_category), ''), 'general'))
  returning id into new_poll_id;

  foreach option_text in array p_options loop
    insert into public.poll_options(poll_id, label, position)
    values (new_poll_id, trim(option_text), option_index);
    option_index := option_index + 1;
  end loop;
  return new_poll_id;
end;
$$;

create or replace function public.submit_vote(p_poll_id uuid, p_option_id uuid, p_voter_token text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_voter_token is null or length(p_voter_token) < 20 or length(p_voter_token) > 100 then
    raise exception 'Invalid voter token.';
  end if;
  if not exists (select 1 from public.polls where id = p_poll_id and is_open = true) then
    raise exception 'This Picksy is closed or no longer exists.';
  end if;
  if not exists (select 1 from public.poll_options where id = p_option_id and poll_id = p_poll_id) then
    raise exception 'That option does not belong to this Picksy.';
  end if;
  insert into public.poll_votes(poll_id, option_id, voter_token)
  values (p_poll_id, p_option_id, p_voter_token)
  on conflict (poll_id, voter_token) do nothing;
  if not found then
    raise exception 'You have already voted on this Picksy.';
  end if;
end;
$$;

create or replace function public.get_poll_results(p_poll_id uuid)
returns table(option_id uuid, option_label text, vote_count bigint)
language sql
security definer
set search_path = public
stable
as $$
  select o.id, o.label, count(v.id)::bigint
  from public.poll_options o
  left join public.poll_votes v on v.option_id = o.id and v.poll_id = p_poll_id
  where o.poll_id = p_poll_id
  group by o.id, o.label, o.position
  order by o.position;
$$;

revoke all on function public.create_poll(text, text, text[]) from public;
revoke all on function public.submit_vote(uuid, uuid, text) from public;
revoke all on function public.get_poll_results(uuid) from public;
grant execute on function public.create_poll(text, text, text[]) to anon, authenticated;
grant execute on function public.submit_vote(uuid, uuid, text) to anon, authenticated;
grant execute on function public.get_poll_results(uuid) to anon, authenticated;

grant select on public.polls, public.poll_options to anon, authenticated;
