"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabase";

type Poll = { id: string; question: string; category: string; created_at: string; };
type Option = { id: string; label: string; position: number; };
type Result = { option_id: string; option_label: string; vote_count: number; };

function voterToken() {
  const key = "picksy-voter-token";
  let token = localStorage.getItem(key);
  if (!token) {
    token = crypto.randomUUID();
    localStorage.setItem(key, token);
  }
  return token;
}

export default function PollPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const [poll, setPoll] = useState<Poll | null>(null);
  const [options, setOptions] = useState<Option[]>([]);
  const [results, setResults] = useState<Result[]>([]);
  const [selected, setSelected] = useState("");
  const [voted, setVoted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const refreshResults = useCallback(async () => {
    if (!supabase || !id) return;
    const { data } = await supabase.rpc("get_poll_results", { p_poll_id: id });
    if (data) setResults(data as Result[]);
  }, [id]);

  useEffect(() => {
    let active = true;
    async function load() {
      if (!supabase) { setError("The app hasn't been connected to its database yet."); setLoading(false); return; }
      const [{ data: pollData, error: pollError }, { data: optionData }] = await Promise.all([
        supabase.from("polls").select("id,question,category,created_at").eq("id", id).maybeSingle(),
        supabase.from("poll_options").select("id,label,position").eq("poll_id", id).order("position")
      ]);
      if (!active) return;
      if (pollError || !pollData) setError("We couldn't find this Picksy. Check the link and try again.");
      else {
        setPoll(pollData as Poll);
        setOptions((optionData ?? []) as Option[]);
        const { data: prior } = await supabase.from("poll_votes").select("id").eq("poll_id", id).eq("voter_token", voterToken()).maybeSingle();
        if (prior) setVoted(true);
        await refreshResults();
      }
      setLoading(false);
    }
    load();
    const timer = setInterval(refreshResults, 3000);
    return () => { active = false; clearInterval(timer); };
  }, [id, refreshResults]);

  async function castVote() {
    if (!supabase || !selected) return;
    setBusy(true); setError("");
    const { error: voteError } = await supabase.rpc("submit_vote", {
      p_poll_id: id, p_option_id: selected, p_voter_token: voterToken()
    });
    setBusy(false);
    if (voteError) setError(voteError.message.includes("already") ? "You've already voted on this Picksy." : voteError.message);
    else { setVoted(true); await refreshResults(); }
  }

  async function share() {
    const url = window.location.href;
    if (navigator.share) await navigator.share({ title: "Join my Picksy", text: poll?.question ?? "Vote with us", url });
    else { await navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 2200); }
  }

  const total = results.reduce((sum, item) => sum + Number(item.vote_count), 0);
  const winner = results.reduce<Result | null>((best, item) => !best || Number(item.vote_count) > Number(best.vote_count) ? item : best, null);

  return <main className="shell poll-shell">
    <header className="topbar"><a className="brand" href="/"><span className="brand-mark">✓</span> picksy<span className="brand-dot">.</span></a><button className="share-button" onClick={share}>↗ Share</button></header>
    <section className="poll-card card">
      {loading ? <div className="loading">Loading your Picksy…</div> : error && !poll ? <div className="empty-state"><h1>Oops!</h1><p>{error}</p><a className="primary-button link-button" href="/">Create a new Picksy</a></div> : poll && <>
        <span className="poll-category">{poll.category} PICKSY</span>
        <h1 className="poll-question">{poll.question}</h1>
        <p className="poll-subtitle">{voted ? "Thanks for voting. Here's how everyone voted." : "Choose your favourite option."}</p>
        <div className="vote-options">
          {options.map(option => {
            const result = results.find(r => r.option_id === option.id);
            const count = Number(result?.vote_count ?? 0);
            const percent = total ? Math.round(count / total * 100) : 0;
            return <button key={option.id} disabled={voted} onClick={() => setSelected(option.id)} className={`vote-option ${selected === option.id ? "chosen" : ""}`}>
              <span className="vote-option-top"><span className="radio-dot">{selected === option.id ? "✓" : ""}</span><b>{option.label}</b>{voted && <strong>{percent}%</strong>}</span>
              {voted && <span className="result-track"><span style={{ width: `${percent}%` }} /></span>}
              {voted && <span className="vote-count">{count} {count === 1 ? "vote" : "votes"}</span>}
            </button>;
          })}
        </div>
        {error && <p className="error">{error}</p>}
        {!voted ? <button className="primary-button create-button" disabled={!selected || busy} onClick={castVote}>{busy ? "Submitting…" : "Submit my vote"} <span>→</span></button> :
          <div className="winner-box"><span>🏆</span><div><b>{winner?.option_label ?? "Waiting for votes"} {winner ? "is leading!" : ""}</b><small>{total} {total === 1 ? "vote" : "votes"} so far · Results refresh automatically</small></div></div>}
        <button className="secondary-button" onClick={share}>{copied ? "Link copied!" : "↗ Invite more people"}</button>
        <p className="fine-print">One group. One decision. Done.</p>
      </>}
    </section>
    <footer><a className="brand footer-brand" href="/">picksy<span className="brand-dot">.</span></a><span>Make your own decision together.</span></footer>
  </main>;
}
