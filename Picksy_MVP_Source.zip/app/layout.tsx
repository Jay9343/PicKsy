import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Picksy — Stop debating. Start deciding.",
  description: "Make decisions together. Create a Picksy, share it with friends and let everyone vote.",
  applicationName: "Picksy",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "Picksy" },
  manifest: "/manifest.webmanifest"
};
export const viewport: Viewport = {
  themeColor: "#17152a",
  width: "device-width",
  initialScale: 1
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
