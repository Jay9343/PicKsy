"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

const categories = [
  { name: "Food", emoji: "🍕", question: "Where should we eat?", options: ["Pizza", "Burgers", "Chinese", "Indian"] },
  { name: "Films", emoji: "🎬", question: "What should we watch?", options: ["Comedy", "Action", "Horror", "Thriller"] },
  { name: "Activities", emoji: "🎳", question: "What should we do?", options: ["Bowling", "Cinema", "Mini golf", "Go karting"] },
  { name: "General", emoji: "✨", question: "What should we choose?", options: ["Option A", "Option B", "Option C", "Option D"] }
];

export default function Home() {
  const router = useRouter();
  const [category, setCategory] = useState(categories[0]);
  const [question, setQuestion] = useState(categories[0].question);
  const [options, setOptions] = useState<string[]>(categories[0].options);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function chooseCategory(item: typeof categories[number]) {
    setCategory(item); setQuestion(item.question); setOptions([...item.options]); setError("");
  }
  function updateOption(index: number, value: string) {
    setOptions(current => current.map((option, i) => i === index ? value : option));
  }
  function addOption() {
    if (options.length < 8) setOptions(current => [...current, ""]);
  }
  function removeOption(index: number) {
    if (options.length > 2) setOptions(current => current.filter((_, i) => i !== index));
  }
  async function createPoll() {
    setError("");
    const cleanOptions = options.map(x => x.trim()).filter(Boolean);
    if (!question.trim()) return setError("Add a question first.");
    if (cleanOptions.length < 2) return setError("Add at least two voting options.");
    if (new Set(cleanOptions.map(x => x.toLowerCase())).size !== cleanOptions.length) return setError("Please remove duplicate options.");
    if (!supabase) return setError("Connect your Supabase project using the setup guide before creating live polls.");
    setLoading(true);
    const { data, error: rpcError } = await supabase.rpc("create_poll", {
      p_question: question.trim(),
      p_category: category.name.toLowerCase(),
      p_options: cleanOptions
    });
    setLoading(false);
    if (rpcError || !data) return setError(rpcError?.message ?? "Couldn't create your Picksy. Please try again.");
    router.push(`/p/${data}`);
  }

  return <main className="shell">
    <header className="topbar">
      <a className="brand" href="/"><span className="brand-mark">✓</span> picksy<span className="brand-dot">.</span></a>
      <span className="top-note">A better way to decide</span>
    </header>
    <section className="hero">
      <div className="eyebrow"><span className="spark">✦</span> LESS DEBATING, MORE DOING</div>
      <h1>Stop debating.<br/><span>Start deciding.</span></h1>
      <p>Make a choice together. Share it with your people. Let the votes decide.</p>
    </section>
    <section className="builder card">
      <div className="section-heading"><div><span className="step">01</span><h2>What are we deciding?</h2></div><span className="small-muted">Choose a category</span></div>
      <div className="category-grid">
        {categories.map(item => <button key={item.name} onClick={() => chooseCategory(item)} className={`category ${category.name === item.name ? "selected" : ""}`}>
          <span>{item.emoji}</span><b>{item.name}</b>
        </button>)}
      </div>
      <label className="field-label" htmlFor="question">Your question</label>
      <input id="question" className="text-input" maxLength={100} value={question} onChange={e => setQuestion(e.target.value)} placeholder="What are we deciding?"/>
      <div className="options-heading"><label className="field-label">Voting options</label><span className="small-muted">{options.length}/8</span></div>
      <div className="option-list">
        {options.map((option, i) => <div className="option-row" key={i}>
          <span className="option-number">{String.fromCharCode(65 + i)}</span>
          <input className="text-input option-input" maxLength={60} value={option} onChange={e => updateOption(i, e.target.value)} placeholder={`Option ${i + 1}`}/>
          {options.length > 2 && <button className="remove-option" onClick={() => removeOption(i)} aria-label="Remove option">×</button>}
        </div>)}
      </div>
      {options.length < 8 && <button className="add-option" onClick={addOption}>＋ Add another option</button>}
      {error && <p className="error">{error}</p>}
      <button className="primary-button create-button" disabled={loading} onClick={createPoll}>{loading ? "Creating your Picksy…" : "Create my Picksy"} <span>→</span></button>
      <p className="fine-print">Free to create. Share a link so everyone can vote.</p>
    </section>
    <section className="how">
      <div className="section-heading"><div><span className="step">02</span><h2>How Picksy works</h2></div></div>
      <div className="how-grid">
        <article><span className="how-icon">✍️</span><h3>Make a Picksy</h3><p>Write a question and add the options.</p></article>
        <article><span className="how-icon">📲</span><h3>Share with everyone</h3><p>Send one link to your group chat.</p></article>
        <article><span className="how-icon">🏆</span><h3>Let the votes decide</h3><p>See the results and settle it together.</p></article>
      </div>
    </section>
    <footer><a className="brand footer-brand" href="/">picksy<span className="brand-dot">.</span></a><span>One group. One decision. Done.</span></footer>
  </main>;
}
