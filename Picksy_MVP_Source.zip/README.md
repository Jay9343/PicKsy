# Picksy — MVP starter

A mobile-first, installable web app for creating shareable group polls. This project is the first real application build, not just a visual mock-up.

## What is included

- Responsive mobile-first interface and Picksy branding
- Create polls in Food, Films, Activities and General categories
- Between 2 and 8 custom options
- Shareable poll URLs
- Voting without account creation
- One vote per browser-generated voter token per poll
- Results refresh every 3 seconds
- Supabase database schema and server-side RPC validation
- PWA manifest for installation from a supported mobile browser

## Important limitations of this MVP

- This is an installable web app (PWA), not yet a native App Store / Google Play binary.
- Voter-token uniqueness is a lightweight anti-duplicate measure, not strong identity verification. Clearing browser storage or using another device can create another token.
- Poll creation is currently anonymous and has no spam/rate limiting. Before public launch, add CAPTCHA or equivalent abuse controls, rate limiting, reporting, deletion and moderation.
- Results are refreshed by polling every three seconds, rather than Supabase Realtime subscriptions.
- No payments, paid plans, advertising, admin dashboard, account system, email flows or analytics have been activated yet.
- Add a privacy policy, terms, contact details and appropriate data-retention rules before inviting the public.
- The Supabase anonymous key is designed to be public when RLS and database permissions are correctly configured. Never put a Supabase service-role key in the browser.

## 1. Create Supabase backend

1. Create a project at https://supabase.com.
2. Open SQL Editor in the Supabase dashboard.
3. Run the complete contents of `supabase/schema.sql`.
4. In Project Settings → API, copy the Project URL and anon/public key.

## 2. Configure environment

Copy `.env.example` to `.env.local` and fill in:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_SITE_URL`

Do not use a service-role key in the frontend.

## 3. Run locally

Requires Node.js 20 or later.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## 4. Deploy

A straightforward option is Vercel:

1. Push this project to a private GitHub repository.
2. Import the repository into Vercel.
3. Add the three environment variables in Vercel project settings.
4. Deploy.
5. Add your production domain to `NEXT_PUBLIC_SITE_URL`.

Then test poll creation, voting from two different devices/browsers, repeat voting, invalid links and mobile layouts.

## 5. Make it installable

Once deployed over HTTPS:
- iPhone: open the website in Safari → Share → Add to Home Screen.
- Android: open in Chrome → browser menu → Install app / Add to Home screen.

A later native release can use a wrapper or a React Native / Expo client sharing the same Supabase backend.

## Production launch checklist

Before accepting payments or promoting widely:
- Add CAPTCHA and rate limiting to anonymous poll creation and voting.
- Add poll expiry/closure, owner controls and deletion.
- Add reporting and moderation tools.
- Add privacy policy, terms, cookie/data disclosures and contact details.
- Add automated tests and error monitoring.
- Add analytics with appropriate consent and privacy controls.
- Implement and test payment flows server-side (e.g. Stripe Checkout + verified webhooks).
- Configure backups, database limits and abuse monitoring.
- Complete Apple/Google developer accounts and store review if native store distribution is wanted.

## Product direction

Keep creating and voting free to preserve sharing. Test premium features only after users demonstrate repeat use. Potential future premium features include custom themes, private recurring groups, advanced poll formats and saved decision history.
